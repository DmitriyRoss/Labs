#include <stdio.h>

int main()
{
    int k, m, n;
    int tmp1;
    int tmp2;
    int tmp3;

    scanf("%d", &k);
    scanf("%d", &m);
    scanf("%d", &n);

    if (k > m && k > n)
    {
        tmp1 = k;
        k = n;
        n = tmp1;
    }
    else if (k < m && k > n)
    {
        tmp1 = k;
        tmp2 = m;
        tmp3 = n;
        k = tmp3;
        m = tmp1;
        n = tmp2;
    }
    else if (k > m && k < n)
    {
        tmp1 = k;
        tmp2 = m;
        tmp3 = n;
        k = tmp2;
        m = tmp1;
        n = tmp3;
    }
    printf("K<M<N: %d,%d,%d", k, m, n);

    return 0;
}
