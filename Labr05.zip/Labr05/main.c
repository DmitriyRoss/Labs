#include <stdio.h>

int main()
{
    int a;
    int b;
    int num[6] = {1, 0, 2, 3, 0, 0};
    for (int i = 0; i < 3; i++)
    {
        a = a + num[i];
    }
    for (int i = 0; i < 6; i++)
    {
        b = b + num[i];
    }
    a *= 2;
    if (a == b)
    {
        printf("Congrats! Your ticket is lucky!");
    }
    else
    {
        printf("We are really sorry. Try again!");
    }

    return 0;
}
